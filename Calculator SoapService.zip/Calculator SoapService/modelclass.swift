//
//  modelclass.swift
//  Calculator SoapService
//
//  Created by TOPS on 7/27/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class modelclass: NSObject {

    var intA:String?
    var intB:String?
    init(intA:String,intB:String) {
    
        self.intA = intA;
        self.intB = intB;
        
    }
    
    
}
