

import UIKit

class ViewController: UIViewController,XMLParserDelegate{

    @IBOutlet weak var lbl: UILabel!
    @IBOutlet weak var txt2: UITextField!
    @IBOutlet weak var answer: UITextView!
    
    @IBOutlet weak var txt1: UITextField!
    
    var strcontent:String = "";
    override func viewDidLoad() {
        super.viewDidLoad()
            }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
        
    }
    
    
    @IBAction func subtract_btn(_ sender: Any) {
        lbl.text = "-";
        sub();
    }
    
    @IBAction func dividebtn(_ sender: Any) {
        lbl.text = "/";
        divi();
    }
    
    @IBAction func multiplybtn(_ sender: Any) {
        lbl.text = "*"
        multi();
    }
    @IBAction func clearbtn(_ sender: Any) {
        txt1.text = "";
        txt2.text = "";
        answer.text = "";
        lbl.text = "";
        
    }
    @IBAction func addbtn(_ sender: Any) {
        lbl.text = "+";
        
         addvalue();
        
        
    }
    func divi() {
        let url = URL(string:"http://www.dneonline.com/calculator.asmx");
        let soapbody = "<?xml version=\"1.0\" encoding=\"utf-8\"?><soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"><soap:Body><Divide xmlns=\"http://tempuri.org/\"><intA>\(txt1.text!)</intA><intB>\(txt2.text!)</intB></Divide></soap:Body></soap:Envelope>"
        var request = URLRequest(url: url!);
        request.addValue(String(soapbody.characters.count), forHTTPHeaderField:"Content-Length");
        request.addValue("http://tempuri.org/Divide", forHTTPHeaderField:"SOAPAction");
        request.addValue("text/xml; charset=utf-8", forHTTPHeaderField:"Content-Type");
        request.httpMethod = "POST";
        request.httpBody = soapbody.data(using: String.Encoding.utf8);
        
        let  session = URLSession.shared;
        let datatask = session.dataTask(with: request) { (data1, resp, err) in
            
            if err == nil{
                
                let  strp = String(data: data1!, encoding: String.Encoding.utf8);
                
                let parse = XMLParser(data: data1!);
                parse.delegate = self;
                parse.parse();
            }
        }
        datatask.resume();
        

    
    }
    func multi(){
        let url = URL(string:"http://www.dneonline.com/calculator.asmx");
        let soapbody = "<?xml version=\"1.0\" encoding=\"utf-8\"?><soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"><soap:Body><Multiply xmlns=\"http://tempuri.org/\"><intA>\(txt1.text!)</intA><intB>\(txt2.text!)</intB></Multiply></soap:Body></soap:Envelope>"
        var request = URLRequest(url: url!);
        request.addValue(String(soapbody.characters.count), forHTTPHeaderField:"Content-Length");
        request.addValue("http://tempuri.org/Multiply", forHTTPHeaderField:"SOAPAction");
        request.addValue("text/xml; charset=utf-8", forHTTPHeaderField:"Content-Type");
        request.httpMethod = "POST";
        request.httpBody = soapbody.data(using: String.Encoding.utf8);
        
        let  session = URLSession.shared;
        let datatask = session.dataTask(with: request) { (data1, resp, err) in
            
            if err == nil{
                
                let  strp = String(data: data1!, encoding: String.Encoding.utf8);
               
                let parse = XMLParser(data: data1!);
                parse.delegate = self;
                parse.parse();
            }
        }
        datatask.resume();
        
        
    }
    func sub(){
        let url = URL(string:"http://www.dneonline.com/calculator.asmx");
        let soapbody = "<?xml version=\"1.0\" encoding=\"utf-8\"?><soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"><soap:Body><Subtract xmlns=\"http://tempuri.org/\"><intA>\(txt1.text!)</intA><intB>\(txt2.text!)</intB></Subtract></soap:Body></soap:Envelope>"
        var request = URLRequest(url: url!);
        request.addValue(String(soapbody.characters.count), forHTTPHeaderField:"Content-Length");
        request.addValue("http://tempuri.org/Subtract", forHTTPHeaderField:"SOAPAction");
        request.addValue("text/xml; charset=utf-8", forHTTPHeaderField:"Content-Type");
        request.httpMethod = "POST";
        request.httpBody = soapbody.data(using: String.Encoding.utf8);
        
        let  session = URLSession.shared;
        let datatask = session.dataTask(with: request) { (data1, resp, err) in
            
            if err == nil{
                
                let  strp = String(data: data1!, encoding: String.Encoding.utf8);
                
                let parse = XMLParser(data: data1!);
                parse.delegate = self;
                parse.parse();
            }
        }
        datatask.resume();
    }

        func addvalue(){
        let url = URL(string:"http://www.dneonline.com/calculator.asmx");
        let soapbody = "<?xml version=\"1.0\" encoding=\"utf-8\"?><soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"><soap:Body><Add xmlns=\"http://tempuri.org/\"><intA>\(txt1.text!)</intA><intB>\(txt2.text!)</intB></Add></soap:Body></soap:Envelope>"
        var request = URLRequest(url: url!);
        request.addValue(String(soapbody.characters.count), forHTTPHeaderField:"Content-Length");
        request.addValue("http://tempuri.org/Add", forHTTPHeaderField:"SOAPAction");
        request.addValue("text/xml; charset=utf-8", forHTTPHeaderField:"Content-Type");
        request.httpMethod = "POST";
        request.httpBody = soapbody.data(using: String.Encoding.utf8);
        
        let  session = URLSession.shared;
        let datatask = session.dataTask(with: request) { (data1, resp, err) in
            
            if err == nil{
                
                let  strp = String(data: data1!, encoding: String.Encoding.utf8);
               
                let parse = XMLParser(data: data1!);
                parse.delegate = self;
                parse.parse();
            }
        }
        datatask.resume();
    }

    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        if elementName == "AddResult" || elementName == "SubtractResult" || elementName == "MultiplyResult" || elementName == "DivideResult"{
            DispatchQueue.main.async {
                self.answer.text = self.strcontent;
            }
        }

    }
   
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        strcontent = string;
    }
    
}

