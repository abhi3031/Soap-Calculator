//
//  controllerclass.swift
//  Calculator SoapService
//
//  Created by TOPS on 7/27/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit
protocol customprotocol {
   func responce(str:String);
//    func data(dt:Data);
}

class controllerclass: NSObject,XMLParserDelegate{
    var delegate:customprotocol?
     var strcontent:String = "";
    func add(obj:modelclass) {
        let url = URL(string:"http://www.dneonline.com/calculator.asmx");
        let soapbody = "<?xml version=\"1.0\" encoding=\"utf-8\"?><soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"><soap:Body><Add xmlns=\"http://tempuri.org/\"><intA>\(obj.intA)</intA><intB>\(obj.intB)</intB></Add></soap:Body></soap:Envelope>"
        var request = URLRequest(url: url!);
        request.addValue(String(soapbody.characters.count), forHTTPHeaderField:"Content-Length");
        request.addValue("http://tempuri.org/Add", forHTTPHeaderField:"SOAPAction");
        request.addValue("text/xml; charset=utf-8", forHTTPHeaderField:"Content-Type");
        request.httpMethod = "POST";
        request.httpBody = soapbody.data(using: String.Encoding.utf8);
        
        let  session = URLSession.shared;
        let datatask = session.dataTask(with: request) { (data1, resp, err) in
            
            if err == nil{
                
                let  strp = String(data: data1!, encoding: String.Encoding.utf8);
              //  print(strp)
//                self.delegate?.responce(str: strp!);
//                self.delegate?.data(dt: data1!);
              let parse = XMLParser(data: data1!);
              parse.delegate = self;
              parse.parse();
            }
        }
        datatask.resume();
}



    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        if elementName == "AddResult" {
            DispatchQueue.main.async {
                self.delegate?.responce(str: self.strcontent);
                //self.answer.text = self.strcontent;
            }
            
        }
        
    }
    
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        strcontent = string;
    }

}
